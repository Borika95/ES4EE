{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "bfbad03a-ef27-43cb-85db-d1b6e77aeae5",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "",
   "name": ""
  },
  "language_info": {
   "name": ""
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
